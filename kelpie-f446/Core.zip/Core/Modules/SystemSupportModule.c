/*
 * SystemSupportModule.c
 *
 *  Created on: Dec 24, 2022
 *      Author: mingy
 */

#include "SystemSupportModule.h"
#include "SerialDebugDriver.h"
