/*
 * SystemSupportTask.c
 *
 *  Created on: Dec 24, 2022
 *      Author: mingy
 */

#include "SystemSupportModule.h"
#include "SystemSupportTask.h"
