/*
 * TaskManger.h
 *
 *  Created on: Oct 22, 2022
 *      Author: mingy
 */

#ifndef TASKS_TASKMANAGER_H_
#define TASKS_TASKMANAGER_H_


#include <stdint.h>

void RunTaskManager( void );

#endif /* TASKS_TASKMANAGER_H_ */
